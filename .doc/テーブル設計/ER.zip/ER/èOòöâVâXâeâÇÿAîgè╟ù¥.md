%% -----------------------------------
%% 外部システム連携管理 (External System Integration Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Users ||--o{ UserExternalCodes : "対象"

  %% 40-UserExternalCodes
  %% ユーザーの外部システムコードを管理するテーブル
  UserExternalCodes {
    integer id PK "AUTO_INCREMENT" %% ユーザー外部コードのユニークなID
    reference user_id FK "NOT_NULL" %% 関連するユーザーID
    string(255) external_code "NOT_NULL" %% 外部システムでのコード
    datetime created_at %% 作成日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
