%% -----------------------------------
%% セキュリティログ管理 (Security Logs Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ SecurityLogs : "belong"

  %% SecurityLogs
  %% セキュリティログ情報を管理するテーブル
  SecurityLogs {
    integer id PK "AUTO_INCREMENT" %% セキュリティログのユニークなID
    string(64) entity_type "NOT_NULL: User, Operator, Company, Admin" %% 操作エンティティの種別
    integer entity_id "NOT_NULL" %% 操作を行ったエンティティID
    string(32) action_type "NOT_NULL: LOGIN, LOGOUT, DATA_ACCESS, DATA_CREATE, DATA_UPDATE, DATA_DELETE" %% 操作の種類
    string(255) action_detail %% 操作の詳細
    string(39) ip_address "NOT_NULL" %% 操作者のIPアドレス
    text user_agent %% 操作者のユーザーエージェント
    datetime created_at "NOT_NULL" %% 操作日時
  }
