%% -----------------------------------
%% お知らせ管理 (Notification Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Notifications ||--o{ NotificationReceivers : "管理"
  Notifications ||--o{ NotificationCategories: "belongs to"
  Notifications ||--o{ NotificationSenders : "送信者"
  Users ||--o{ NotificationReceivers : "対象"
  Operators ||--o{ NotificationReceivers : "対象"
  Companies ||--o{ NotificationReceivers : "対象"
  Sites ||--o{ NotificationReceivers : "対象"
  NotificationReceivers ||--o{ NotificationSendMethods : "belongs to"
  NotificationCategories ||--o{ NotificationCategories: "parent-child"

  %% 30-Notifications
  %% お知らせ情報を管理するテーブル
  Notifications {
    integer id PK "AUTO_INCREMENT" %% お知らせのユニークなID
    string(64) notification_code UK "NOT_NULL" %% お知らせコード（ユニーク）
    reference category_id FK "NOT_NULL: NotificationCategories.id" %% お知らせカテゴリID
    string(64) title "NOT_NULL" %% お知らせタイトル
    text content "NOT_NULL" %% お知らせ内容
    datetime publish_start_at "NOT_NULL" %% 公開開始日時
    datetime publish_end_at %% 公開終了日時
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 31-NotificationCategories
  %% お知らせカテゴリ情報を管理するテーブル
  NotificationCategories {
    integer id PK "AUTO_INCREMENT" %% カテゴリのユニークなID
    string(64) name "NOT_NULL" %% カテゴリ名
    string(255) description %% カテゴリ説明
    reference parent_id FK "NULL: NotificationCategories.id" %% 親カテゴリID（階層構造用）
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 32-NotificationReceivers
  %% お知らせ受信対象を管理するテーブル
  NotificationReceivers {
    integer id PK "AUTO_INCREMENT" %% 受信対象のユニークなID
    reference notification_id FK "NOT_NULL" %% お知らせID
    string(64) entity_type "NOT_NULL" %% 受信対象のエンティティ種別（例: Users, Operators）
    integer entity_id FK "NOT_NULL" %% 受信対象のエンティティID
    reference send_method_id FK "NOT_NULL: NotificationSendMethods.id" %% 送信方法ID
    datetime sent_at "NOT_NULL" %% 送信日時
    boolean is_read "Mark as read status: default: false" %% 既読フラグ（デフォルトは未読）
    datetime read_at "Mark as read date and time" %% 既読日時
    datetime created_at "NOT_NULL" %% 作成日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 33-NotificationSenders
  %% お知らせ送信者を管理するテーブル
  NotificationSenders {
    integer id PK "AUTO_INCREMENT" %% 送信者のユニークなID
    reference notification_id FK "NOT_NULL" %% お知らせID
    string(64) entity_type "NOT_NULL" %% 送信者のエンティティ種別
    integer entity_id FK "NOT_NULL" %% 送信者のエンティティID
    datetime created_at "NOT_NULL" %% 作成日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 34-NotificationSendMethods
  %% お知らせ送信方法を管理するテーブル
  NotificationSendMethods {
    integer id PK "AUTO_INCREMENT" %% 送信方法のユニークなID
    string(64) name "NOT_NULL" %% 送信方法名
    string(255) description %% 送信方法の説明
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
