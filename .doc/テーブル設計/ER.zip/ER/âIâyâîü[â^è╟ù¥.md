%% -----------------------------------
%% オペレータ管理 (Operator Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Operators ||--|| OperatorRanks: "has"
  Operators ||--o{ SiteOperators: "belong"
  SiteOperators ||--o{ SiteOperatorRoles: "belong"
  Companies ||--o{ Sites: "has"
  Companies ||--o{ Operators: "has"

  %% 20-Operators
  %% 各オペレータの情報を管理するテーブル
  Operators {
    integer id PK "AUTO_INCREMENT" %% オペレータのユニークなID
    string(64) operator_code UK "NOT_NULL" %% オペレータコード（ユニーク）
    reference company_id FK "NOT_NULL: Companies.id" %% 所属する会社ID
    string(32) name "NOT_NULL" %% オペレータ名
    reference operator_rank_id FK "NOT_NULL: OperatorRanks.id" %% オペレータランクID
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 21-SiteOperators
  %% サイトに紐づくオペレータを管理するテーブル
  SiteOperators {
    integer id PK "AUTO_INCREMENT" %% サイトオペレータのユニークなID
    reference site_id FK "NOT_NULL: Sites.id" %% 関連するサイトID
    reference operator_id FK "NOT_NULL: Operators.id" %% 関連するオペレータID
    reference role_id FK "NOT_NULL: SiteOperatorRoles.id" %% サイトオペレータの役割ID
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 22-OperatorRanks
  %% オペレータランクを管理するテーブル
  OperatorRanks {
    integer id PK "AUTO_INCREMENT" %% オペレータランクのユニークなID
    string(32) name "NOT_NULL" %% ランク名
    integer priority "NOT_NULL: default: 1" %% ランクの優先度
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 23-SiteOperatorRoles
  %% サイトオペレータの役割を管理するテーブル
  SiteOperatorRoles {
    integer id PK "AUTO_INCREMENT" %% サイトオペレータロールのユニークなID
    string(32) name "NOT_NULL" %% 役割名
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 24-Companies
  %% 会社情報を管理するテーブル
  Companies {
    integer id PK "AUTO_INCREMENT" %% 会社のユニークなID
    string(64) company_code UK "NOT_NULL" %% 会社コード（ユニーク）
    string(32) company_name "NOT_NULL" %% 会社名
    string(64) name "NOT_NULL" %% 登録者名または代表者名
    string(10) postal_code %% 郵便番号
    string(128) address %% 住所
    string(24) phone %% 電話番号
    string(24) phone2 %% 補助電話番号
    string(24) fax %% FAX番号
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 25-Sites
  %% サイト情報を管理するテーブル
  Sites {
    integer id PK "AUTO_INCREMENT" %% サイトのユニークなID
    string(64) site_code UK "NOT_NULL" %% サイトコード（ユニーク）
    reference company_id FK "NOT_NULL: Companies.id" %% 所属する会社ID
    string(255) url UK "NOT_NULL" %% サイトのURL
    string(64) name "NOT_NULL" %% サイト名
    string(255) description %% サイトの説明
    boolean is_btob "default: false" %% BtoBサイトかどうか
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
