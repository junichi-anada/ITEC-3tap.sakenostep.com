%% -----------------------------------
%% 商品管理 (Item Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ Items : "belong"
  Items ||--o{ ItemCategories : "belong"
  Items ||--o{ ItemUnits : "belong"

  %% 60-Items
  %% 商品情報を管理するテーブル
  Items {
    integer id PK "AUTO_INCREMENT" %% 商品のユニークなID
    string(64) item_code UK "NOT_NULL" %% 商品コード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 商品が所属するサイトID
    reference category_id FK "NOT_NULL: ItemCategories.id" %% 商品カテゴリID
    string(64) maker_name %% メーカー名
    string(64) name "NOT_NULL" %% 商品名
    text description %% 商品の説明
    decimal unit_price "NOT_NULL: (10,2)" %% 商品の単価
    reference unit_id FK "NOT_NULL: ItemUnits.id" %% 商品単位ID
    enum from_source "NOT_NULL: MANUAL, IMPORT" %% 商品登録のソース（手動/インポート）
    boolean is_recommended "default: false" %% 推奨商品かどうか
    datetime published_at %% 公開日時
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 61-ItemCategories
  %% 商品カテゴリ情報を管理するテーブル
  ItemCategories {
    integer id PK "AUTO_INCREMENT" %% 商品カテゴリのユニークなID
    string(64) category_code UK "NOT_NULL" %% カテゴリコード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 商品カテゴリが所属するサイトID
    string(64) name "NOT_NULL" %% 商品カテゴリ名
    integer priority "NOT_NULL: default: 1" %% カテゴリの優先順位
    boolean is_published "default: false" %% 公開状態（デフォルトは非公開）
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 62-ItemUnits
  %% 商品単位情報を管理するテーブル
  ItemUnits {
    integer id PK "AUTO_INCREMENT" %% 商品単位のユニークなID
    string(64) unit_code UK "NOT_NULL" %% 商品単位コード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 商品単位が所属するサイトID
    string(64) name "NOT_NULL" %% 商品単位名
    integer priority "NOT_NULL: default: 1" %% 単位の優先順位
    boolean is_published "default: false" %% 公開状態（デフォルトは非公開）
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
