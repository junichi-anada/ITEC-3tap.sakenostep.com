%% -----------------------------------
%% パスワード履歴管理 (Password History Management)
%% version 1.0
%% -----------------------------------
erDiagram
  %% PasswordHistories
  %% パスワード履歴情報を管理するテーブル
  PasswordHistories {
    integer id PK "AUTO_INCREMENT" %% パスワード履歴のユニークなID
    reference authenticate_id FK "NOT_NULL: Authenticates.id" %% 関連する認証ID
    string password "NOT_NULL" %% 保存されたパスワード（ハッシュ化）
    datetime created_at "NOT_NULL" %% パスワード保存日時
  }
