%% -----------------------------------
%% ユーザー情報管理 (Customer Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ Users : "belong"

  %% 80-Users
  %% 顧客情報を管理するテーブル
  Users {
    integer id PK "AUTO_INCREMENT" %% 顧客のユニークなID
    string(64) user_code UK "NOT_NULL" %% 顧客コード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 顧客が所属するサイトID
    string(64) name "NOT_NULL" %% 顧客名
    string(32) last_name %% 姓
    string(32) first_name %% 名
    string(32) last_name_kana %% 姓（カナ）
    string(32) first_name_kana %% 名（カナ）
    string(10) postal_code %% 郵便番号
    string(128) address %% 住所
    string(24) phone %% 電話番号
    string(24) phone2 %% 補助電話番号
    string(24) fax %% FAX番号
    datetime created_at %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
