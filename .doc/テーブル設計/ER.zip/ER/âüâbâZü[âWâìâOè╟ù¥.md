%% -----------------------------------
%% メッセージログ管理 (Message Logs Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ MessageLogs : "belong"
  Operators ||--o{ MessageLogs : "send"
  Users ||--o{ MessageLogs : "receive"

  %% MessageLogs
  %% メッセージログ情報を管理するテーブル
  MessageLogs {
    integer id PK "AUTO_INCREMENT" %% メッセージログのユニークなID
    string(64) message_code UK "NOT_NULL" %% メッセージコード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 関連するサイトID
    reference operator_id FK "NOT_NULL: Operators.id" %% メッセージを送信したオペレータID
    reference user_id FK "NOT_NULL: Users.id" %% メッセージを受信したユーザーID
    string(32) message_type "NOT_NULL: LINE等" %% メッセージの種類
    text message_content "NOT_NULL" %% メッセージ内容
    datetime sent_at "NOT_NULL" %% メッセージ送信日時
    datetime created_at "NOT_NULL" %% 作成日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
