%% -----------------------------------
%% インポートタスク管理 (Import Task Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ ImportTasks : "関連"
  Operators ||--o{ ImportTasks : "実行"

  %% ImportTasks
  %% インポートタスク情報を管理するテーブル
  ImportTasks {
    integer id PK "AUTO_INCREMENT" %% インポートタスクのユニークなID
    string task_code "NOT_NULL" %% タスクコード（ユニーク）
    reference site_id FK "Sites.id" %% 関連するサイトID
    reference operator_id FK "Operators.id" %% タスク実行者（オペレータID）
    string data_type "NOT_NULL" %% インポートするデータの種類
    string file_path "NOT_NULL" %% インポートするファイルのパス
    string status "NOT_NULL" %% タスクのステータス（例: Pending, Processing, Completed）
    string status_message "nullable" %% ステータスメッセージ
    datetime uploaded_at "NOT_NULL" %% アップロード日時
    datetime imported_at "nullable" %% インポート完了日時
  }
