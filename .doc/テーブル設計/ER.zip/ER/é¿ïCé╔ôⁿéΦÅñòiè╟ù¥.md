%% -----------------------------------
%% お気に入り商品管理 (Favorite Item Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ FavoriteItems : "belong"
  Users ||--o{ FavoriteItems : "belong"
  Items ||--o{ FavoriteItems : "belong"  

  %% 50-FavoriteItems
  %% お気に入り商品情報を管理するテーブル
  FavoriteItems {
    integer id PK "AUTO_INCREMENT" %% お気に入り商品のユニークなID
    reference user_id FK "NOT_NULL" %% お気に入り登録したユーザーID
    reference item_id FK "NOT_NULL" %% お気に入り登録された商品ID
    reference site_id FK "NOT_NULL" %% 関連するサイトID
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at "NOT_NULL" %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
