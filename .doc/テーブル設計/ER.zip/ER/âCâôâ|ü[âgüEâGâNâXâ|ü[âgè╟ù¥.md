%% -----------------------------------
%% インポート/エクスポート管理 (Import/Export Management)
%% version 1.0
%% -----------------------------------
erDiagram
  Sites ||--o{ ImportExportLogs : "belong"
  Operators ||--o{ ImportExportLogs : "execute"

  %% ImportExportLogs
  %% インポート/エクスポートログ情報を管理するテーブル
  ImportExportLogs {
    integer id PK "AUTO_INCREMENT" %% ログのユニークなID
    string(64) log_code UK "NOT_NULL" %% ログコード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 関連するサイトID
    reference operator_id FK "NOT_NULL: Operators.id" %% 操作を実行したオペレータID
    string(32) operation_type "NOT_NULL: IMPORT, EXPORT" %% 操作の種類（インポート/エクスポート）
    string(32) target_type "NOT_NULL: USER, ITEM, ORDER" %% 対象データの種類
    string(255) file_name "NOT_NULL" %% ファイル名
    integer record_count "NOT_NULL" %% 対象レコード数
    string(32) status "NOT_NULL: SUCCESS, FAILED" %% 操作結果のステータス
    text error_detail %% エラー詳細（失敗時）
    datetime created_at "NOT_NULL" %% 作成日時
    datetime deleted_at %% 削除日時（論理削除用）
  }
