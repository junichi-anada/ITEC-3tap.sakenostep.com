%% -----------------------------------
%% ログイン試行管理 (Login Attempts Management)
%% version 1.0
%% -----------------------------------
erDiagram
  %% LoginAttempts
  %% ログイン試行情報を管理するテーブル
  LoginAttempts {
    integer id PK "AUTO_INCREMENT" %% ログイン試行のユニークなID
    string(64) login_id "NOT_NULL" %% 試行されたログインID
    string(39) ip_address "NOT_NULL" %% ログイン試行を行ったIPアドレス
    boolean is_success "NOT_NULL, DEFAULT: false" %% 成功フラグ（デフォルトは失敗）
    text failure_reason %% 失敗理由（成功時はNULL）
    datetime created_at "NOT_NULL" %% 試行日時
  }
