%% -----------------------------------
%% 認証管理 (Authentication Management)
%% version 1.2
%% -----------------------------------
erDiagram
  Authenticates ||--o{ AuthProviders: "uses"
  Authenticates ||--|| UsableSites : "has"
  Users ||--o{ Authenticates: "has"
  Sites ||--o{ Authenticates: "has"
  Sites ||--o{ UsableSites: "has"
  Sites ||--o{ SiteAuthProviders : "can use"
  AuthProviders ||--o{ SiteAuthProviders : "can be used by"

  %% 10-Authenticates
  %% ID/Password認証およびプロバイダ認証情報管理テーブル
  Authenticates {
    integer id PK "AUTO_INCREMENT" %% ユニークな認証レコードID
    string(64) auth_code UK "NOT_NULL" %% 認証コード（ユニーク）
    reference site_id FK "NOT_NULL: Sites.id" %% 関連するサイトID
    string(64) entity_type "NOT_NULL" %% 認証対象のエンティティ種別（例: Users, Companies）
    integer entity_id "NOT_NULL" %% 認証対象のエンティティID
    string(50) login_code "NOT_NULL" %% ログインに使用するコード
    string(255) password %% ハッシュ化されたパスワード
    reference provider_id FK "NOT_NULL: AuthProviders.id" %% 認証プロバイダID
    string(255) token %% 認証トークン（プロバイダ認証用）
    datetime token_expiry %% トークン有効期限（プロバイダ認証用）
    datetime expires_at "NOT_NULL" %% 認証の有効期限
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 12-AuthProviders
  %% 認証プロバイダ管理テーブル（LINE, Google, Facebookなど）
  AuthProviders {
    integer id PK "AUTO_INCREMENT" %% 認証プロバイダーのユニークなID
    string(64) provider_code UK "NOT_NULL" %% プロバイダーコード（ユニーク）
    string(32) name "NOT_NULL" %% 認証プロバイダー名
    string(255) description %% プロバイダーの説明
    boolean  is_enable "default: false" %% 利用可能かどうか（デフォルトは無効）
    string(255) api_key %% APIキー（プロバイダ接続用）
    string(255) api_secret %% APIシークレット（プロバイダ接続用）
    string(255) redirect_url %% リダイレクトURL
    datetime created_at "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 13-UsableSites
  %% ユーザーごとに利用できるサイトの管理テーブル
  UsableSites {
    integer id PK "AUTO_INCREMENT" %% ユニークな使用可能サイトのレコードID
    string(64) entity_type "NOT_NULL" %% サイト利用対象のエンティティ種別
    integer entity_id "NOT_NULL" %% サイト利用対象のエンティティID
    reference site_id "NOT_NULL" %% 利用可能なサイトID
    boolean shared_login_allowed "default: false" %% 共有ログインの可否（デフォルトは不可）
    datetime created_at  "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
    datetime deleted_at %% 削除日時（論理削除用）
  }

  %% 14-SiteAuthProviders
  %% サイトごとに利用できる認証プロバイダの管理テーブル
  SiteAuthProviders {
    integer id PK "AUTO_INCREMENT" %% サイトで使用可能な認証プロバイダーのレコードID
    reference site_id FK "NOT_NULL: Sites.id" %% 関連するサイトID
    reference auth_provider_id FK "NOT_NULL: AuthProviders.id" %% 使用可能な認証プロバイダーID
    boolean is_enabled "default: true" %% 利用可能かどうか（デフォルトは有効）
    datetime created_at  "NOT_NULL" %% 作成日時
    datetime updated_at %% 更新日時
  }
